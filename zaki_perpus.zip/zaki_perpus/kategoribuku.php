<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpus Gaming</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body{
            background-color: bisque;
        }
        nav{
            background-color: goldenrod;
        }
        .navbar-brand{
            padding-left: 30px;
            font-weight: bold;
        }
        .navbar-brand, .navbar-nav a {
            margin-right: 30px;
        }
        .dropdown{
            padding-right: 50px;
        }
        .judul{
            font-size: 30px;
            font-family: 'Poppins';
            font-weight: bold;
            text-decoration: underline;
            margin-top: 50px;
            text-align: center;
        }
        .novel{
            font-size: 20px;
            font-family: 'Poppins';
            font-weight: bold;
            padding-left: 30px;
        }
        .noveldiv{
            margin-left: 100px;
            margin-top: 30px;
        }
        .rounded{
            margin-left: 10px;
        }
        .titik{
            color: bisque;
        }
        .halo{
            margin-top: 50px;
            text-align: center;
            height: 40vh;
            background-color: goldenrod;
            padding-top: 100px;
            background-image: url(assets/img/utama\ \(2\).jpg);
            background-size: cover;
            color: bisque;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">PERPUS GAMING</a>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" aria-current="page" href="#">Kategori Buku</a>
                    <a class="nav-link" href="koleksipribadi.php">Koleksi Pribadi</a>
                    <a class="nav-link" href="pinjambuku.php">Pinjam Buku</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Akun Anda
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="login.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="halo">
        <h2 class="">Selamat Datang di PERPUS GAMING!</h2>
        <h6 class="mt-3">Para peminjam dapat melihat buku, memfavoritkan buku, dan meminjam buku :)</h6>
    </section>
    <p class="judul">DAFTAR BUKU</p>
    <div class="noveldiv">
        <p class="novel">Kategori - Novel</p>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/2001aSpaceOdyssey.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">2001: A Space Odyssey</h5>
                            <p class="card-text">Penulis : Arthur C. Clarke <br>Penerbit : Hutchinson<br>Tahun Terbit : 1968</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/hpatgof.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Harry Potter Year 5</h5>
                            <p class="card-text">Penulis : J.K. Rowling <br>Penerbit : Bloomsbury<br>Tahun Terbit : 2000</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/laskarPelangi.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Laskar Pelangi</h5>
                            <p class="card-text">Penulis : Andrea Hirata <br>Penerbit : Bentang Pustaka<br>Tahun Terbit : 2005</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/marmutMerahJambu.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Marmut Merah Jambu</h5>
                            <p class="card-text">Penulis : Raditya Dika <br>Penerbit : Bukuné<br>Tahun Terbit : 2010</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/tlotr.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">The Lord of the Rings</h5>
                            <p class="card-text">Penulis : J. R. R. Tolkien <br>Penerbit : Allen & Unwin<br>Tahun Terbit : 1968</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/dilan1983.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Dilan 1983</h5>
                            <p class="card-text">Penulis : Pidi Baiq <br>Penerbit : Rapelmedia<br>Tahun Terbit : 2024</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="noveldiv">
        <p class="novel">Kategori - Komik</p>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/blueBox10.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Blue Box Vol. 10</h5>
                            <p class="card-text">Penulis : Kouji Miura <br>Penerbit : Shueisha<br>Tahun Terbit : 2023</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/oneWeekFriends1.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">One Week Friends Vol. 1</h5>
                            <p class="card-text">Penulis : Matcha Hazuki <br>Penerbit : Square Enix<br>Tahun Terbit : 2012</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/jujutsuKaisen16.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Jujutsu Kaisen Vol. 16</h5>
                            <p class="card-text">Penulis : Gege Akutami <br>Penerbit : Shueisha<br>Tahun Terbit : 2021</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/naruto60.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Naruto Vol. 60</h5>
                            <p class="card-text">Penulis : Masashi Kishimoto <br>Penerbit : Shueisha<br>Tahun Terbit : 2012</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card m-lg-2" style="max-width: 415px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="assets/img/sakamotoDays6.jpg" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Sakamoto Days Vol. 6</h5>
                            <p class="card-text">Penulis : Yuto Suzuki <br>Penerbit : Shueisha<br>Tahun Terbit : 2022</p>
                            <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                            <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <h6>
                                                Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                            </h6>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-secondary">Ulasan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="noveldiv">
        <p class="novel">Kategori - Album sih, bukan buku</p>
        <div class="row row-cols-1 row-cols-md-6 g-4">
            <div class="col">
                <div class="card">
                    <img src="assets/img/bintangDiSurga.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Bintang Di Surga</h5>
                        <p class="card-text">Penyanyi : Peterpan <br>Label : Musica Studio's<br>Tahun Terbit : 2004</p>
                        <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>
                                            Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                        </h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <a href="#" class="btn btn-secondary mt-1">Ulasan</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="assets/img/plagiarism.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Plagiarism</h5>
                        <p class="card-text">Penyanyi : Yorushika <br>Label : Universal Music <br>Tahun Terbit : 2020</p>
                        <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>
                                            Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                        </h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <a href="#" class="btn btn-secondary mt-1">Ulasan</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="assets/img/sepertiSeharusnya.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Seperti Seharusnya</h5>
                        <p class="card-text">Penyanyi : Noah <br>Label : Musica Studio's <br>Tahun Terbit : 2012</p>
                        <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>
                                            Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                        </h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <a href="#" class="btn btn-secondary mt-1">Ulasan</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="assets/img/blackParade.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">The Black Parade</h5>
                        <p class="card-text">Penyanyi : MCR <br>Label : Reprise <br>Tahun Terbit : 2006</p>
                        <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>
                                            Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                        </h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <a href="#" class="btn btn-secondary mt-1">Ulasan</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="assets/img/yesOrYes.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Yes Or Yes</h5>
                        <p class="card-text">Penyanyi : Twice <br>Label : JYP Entertainment <br>Tahun Terbit : 2018</p>
                        <a href="pinjambuku.php" class="btn btn-primary">Pinjam</a>
                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal">Favorit</a>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Ingfo</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>
                                            Buku telah ditambahkan ke favorit! <br>Lihat daftar favorit di <a href="koleksipribadi.php">Koleksi Pribadi</a>.
                                        </h6>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <a href="#" class="btn btn-secondary mt-1">Ulasan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="noveldiv">
        <p class="titik">.</p>
    </div>
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>