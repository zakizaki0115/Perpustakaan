<?php
$koneksi=new mysqli('localhost','root','','perpus_zaki') or die(mysqli_error($koneksi));
?>