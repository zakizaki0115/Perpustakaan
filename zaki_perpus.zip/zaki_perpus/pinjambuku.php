<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpus Gaming</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body{
            background-color: bisque;
        }
        nav{
            background-color: goldenrod;
        }
        .navbar-brand{
            padding-left: 30px;
            font-weight: bold;
        }
        .navbar-brand, .navbar-nav a {
            margin-right: 30px;
        }
        .teks{
            text-align: center;
            padding-top: 200px;
            font-family: 'Poppins';
            font-weight: bold;
        }
        .dropdown{
            padding-right: 50px;
        }
        .judul{
            font-size: 30px;
            font-family: 'Poppins';
            font-weight: bold;
            text-decoration: underline;
            margin-top: 30px;
            text-align: center;
        }
        .btn form-control{
            background-color: goldenrod;
            font-weight: bold;
        }
        .btn form-control:hover{
            background-color: darkgoldenrod;
        }
        .container{
            text-align: center;
        }
        .atas{
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="kategoribuku.php">PERPUS GAMING</a>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" href="kategoribuku.php">Kategori Buku</a>
                    <a class="nav-link" href="koleksipribadi.php">Koleksi Pribadi</a>
                    <a class="nav-link active" aria-current="page" href="#">Pinjam Buku</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Akun Anda
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="login.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <p class="judul">PINJAM BUKU</p>
    <div class="container">
        <div class="row justify-content-center mt-0">
            <div class="col-lg-5">
                <div class="card o-hidden border-1 my-0">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-lg">
                                <div class="p-5">
                                    <form action="config.php" method="post">
                                        <h5>Judul Buku</h5>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Judul Buku" aria-label="Judul Buku" aria-describedby="basic-addon1">
                                        </div>
                                        <h5>Penulis Buku</h5>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Penulis Buku" aria-label="Penulis Buku" aria-describedby="basic-addon1">
                                        </div>
                                        <h5>Penerbit Buku</h5>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Penerbit Buku" aria-label="Penerbit Buku" aria-describedby="basic-addon1">
                                        </div>
                                        <h5>Tahun Terbit Buku</h5>
                                        <div class="input-group mb-4">
                                            <input type="text" class="form-control" placeholder="Tahun Terbit Buku" aria-label="Tahun Terbit Buku" aria-describedby="basic-addon1">
                                        </div>
                                        <div class="input-group mt-3">
                                            <a href="kategoribuku.php" class="btn btn-success form-control">Pinjam Buku</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>