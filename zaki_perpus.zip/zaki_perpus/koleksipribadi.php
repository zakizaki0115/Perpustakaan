<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpus Gaming</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        body{
            background-color: bisque;
        }
        nav{
            background-color: goldenrod;
        }
        .navbar-brand{
            padding-left: 30px;
            font-weight: bold;
        }
        .navbar-brand, .navbar-nav a {
            margin-right: 30px;
        }
        .teks{
            text-align: center;
            padding-top: 200px;
            font-family: 'Poppins';
            font-weight: bold;
        }
        .dropdown{
            padding-right: 50px;
        }
        .judul{
            font-size: 30px;
            font-family: 'Poppins';
            font-weight: bold;
            text-decoration: underline;
            margin-top: 30px;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="kategoribuku.php">PERPUS GAMING</a>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" href="kategoribuku.php">Kategori Buku</a>
                    <a class="nav-link active" aria-current="page" href="#">Koleksi Pribadi</a>
                    <a class="nav-link" href="pinjambuku.php">Pinjam Buku</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Akun Anda
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="login.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <p class="judul">KOLEKSI PRIBADI</p>
    <p class="teks">
        Belum ada buku yang difavoritkan :( <br>
        Favoritkan buku di <a href="kategoribuku.php">Kategori Buku</a>!
    </p>
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>